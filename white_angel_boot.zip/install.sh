#!/bin/bash
THEME="white_angel_boot"
THEME_DIR="/usr/share/plymouth/themes/$THEME"

sudo mkdir -p $THEME_DIR
sudo cp white_angel_boot.plymouth $THEME_DIR/
sudo cp white_angel_boot.script $THEME_DIR/
sudo cp -r images $THEME_DIR/

sudo plymouth-set-default-theme -R $THEME
echo "✅ Theme '$THEME' installed and set as default."